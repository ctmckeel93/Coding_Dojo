
import React from 'react'
import './App.css';

import MyComponent from './components/MyComponent';

function App() {
  return (
    <div className="App">
      <MyComponent />
      
    </div>
  );
}

export default App;
