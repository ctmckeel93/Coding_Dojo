// Print all odd numbers between 1 and 20 inclusively

function oddNumbers () {
    for (var i = 1; i<=20; i+=2) {
        console.log(i)
    }
}
oddNumbers()

// sum and print 1-5
sum=0
function sumPrint () {
    for (i=0; i<=5; i++) {
    sum = sum+i
    console.log(i)
    console.log(sum)
    }
}
sumPrint()
